package col106.assignment3.Heap;

public class Heap<T extends Comparable, E extends Comparable> implements HeapInterface <T, E> {
	/* 
	 * Do not touch the code inside the upcoming block 
	 * If anything tempered your marks will be directly cut to zero
	*/
	public static void main() {
		HeapDriverCode HDC = new HeapDriverCode();
		System.setOut(HDC.fileout());
	}
	/*
	 * end code
	 */
	
	// write your code here	
	public void insert(T key, E value) {
		//write your code here
		
	}

	public E extractMax() {
		//write your code here
		return null;
	}

	public void delete(T key) {
		//write your code here
		
	}

	public void increaseKey(T key, E value) {
		//write your code here
		
	}

	public void printHeap() {
		//write your code here
	}	
}
